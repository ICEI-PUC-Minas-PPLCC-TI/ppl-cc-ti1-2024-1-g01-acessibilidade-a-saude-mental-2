#include <stdio.h>
int main(){
  float A, B, temp;
  printf("Digite o valor de A:");
  scanf("%f", &A);

  printf("Digite o valor de B:");
  scanf("%f", &B);

  printf("Antes da troca:\n");
  printf("A = %.2f, B = %.2f", A, B);

  temp = A;
  A = B;
  B = temp;

  printf("\nDepois da troca:");
  printf("A = %.2f, B = %.2f", A, B);

  return 0;
}