#include <stdio.h>
#include <math.h>

int main(){
  float primeiro_termo, razao, quinto_termo;
  printf("Digite o primeiro termo:");
  scanf("%f", &primeiro_termo);

  printf("Digite a razao:");
  scanf("%f", &razao);

  quinto_termo = primeiro_termo * pow(razao ,4);

  printf("O valor do quinto termo é: %.2f", quinto_termo);

  return 0;
}