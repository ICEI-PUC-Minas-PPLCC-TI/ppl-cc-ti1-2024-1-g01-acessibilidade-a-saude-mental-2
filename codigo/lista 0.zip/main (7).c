#include <stdio.h>
int main(){
  float primeiro_termo, razao, decimo_termo;

  printf("Digite o valor do primeiro termo:");
  scanf("%f", &primeiro_termo);

  printf("Digite o valor da razao:");
  scanf("%f", &razao);

  decimo_termo = primeiro_termo + 9 * razao;

  printf("O valor do decimo termo é: %.2f", decimo_termo);

  return 0;
}