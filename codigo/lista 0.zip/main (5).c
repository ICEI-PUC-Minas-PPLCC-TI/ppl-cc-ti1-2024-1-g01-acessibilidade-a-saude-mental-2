#include <stdio.h>
int main() {
  float perimetro, area, raio;
  printf("Digite o raio do círculo:");
  scanf("%f", &raio);

  area = 3.14 * (raio * raio);
  perimetro = 2 * 3.14 * raio;

  printf("O valor do perimetro é: %.2f\n", perimetro);
  printf("O valor da area é: %.2f", area);

  return 0;
}