#include <stdio.h>
#include <math.h>
int main(){
  float cateto1, cateto2, hipotenusa;
  printf("Digite o valor do cateto oposto:");
  scanf("%f", &cateto1);
  printf("Digite o valor do cateto adjacente:");
  scanf("%f", &cateto2);

  hipotenusa = sqrt((cateto1 * cateto1) + (cateto2 * cateto2));
  
  printf("O valor da hipotenusa é: %.2f", hipotenusa);

  return 0;
}