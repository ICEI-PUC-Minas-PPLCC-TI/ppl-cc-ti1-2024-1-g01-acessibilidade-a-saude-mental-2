#include <stdio.h>
int main(){
  int horas, minutos, total_minutos;
  printf("Digite as horas (0-23):");
  scanf("%d", &horas);

  printf("Digite os minutos (0-60):");
  scanf("%d", &minutos);

  total_minutos = horas * 60 + minutos;

  printf("O total de minutos passados é: %d", total_minutos);

  return 0;
}

  