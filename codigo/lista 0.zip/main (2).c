#include <stdio.h>
int main() {
  int num, centena, dezena, unidade, num_invertido;
  printf("Digite um número com três digitos (CDU):");
  scanf("%d", &num);

  centena = num / 100;
  dezena = (num % 100) / 10;
  unidade = num % 10;

  num_invertido = unidade * 100 + dezena * 10 + centena;

  printf("Número invertido (UDC): %d\n", num_invertido);

  return 0;
}
