#include <stdio.h>
int main() {
  float perimetro, area, diagonal;
  int base, altura;
  printf("Digite a base do retangulo:");
  scanf("%d",&base);
  printf("Digite a altura do retangulo:");
  scanf("%d", &altura);

  perimetro = 2 * (base + altura);

  area = base * altura;

  diagonal = 1.0 * base * base + 1.0 * altura * altura;

  printf("O perímetro do retangulo é: %.2f", perimetro);
  printf("\tA área do retangulo é: %.2f", area);
  printf("\tA diagonal do retangulo é: %.2f", diagonal);

  return 0;
}