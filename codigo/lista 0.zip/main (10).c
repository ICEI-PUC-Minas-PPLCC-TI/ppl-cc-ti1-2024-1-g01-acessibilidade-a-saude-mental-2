#include <stdio.h>
#include <math.h>

int main(){
  float numerador, denominador, decimal;
  printf("Digite o numerador:");
  scanf("%f", &numerador);

  printf("Digite o denominador:");
  scanf("%f", &denominador);

  decimal = numerador / denominador;

  printf("O valor em decimal é: %.2f", decimal);

  return 0;
}