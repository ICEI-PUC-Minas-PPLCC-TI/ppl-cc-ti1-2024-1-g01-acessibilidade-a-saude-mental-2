#include <stdio.h>
int main(){
float salario_minimo, valor_por_kwh, total_com_desconto, total_sem_desconto;
int consumo_de_kwh;
  printf("Digite o valor do salário mínimo:");
  scanf("%f", &salario_minimo);

  printf("Digite a quantidade de Kilowatt hora consumida pela residência:");
  scanf("%d", &consumo_de_kwh);

  valor_por_kwh = (salario_minimo/7)/100;

  total_sem_desconto = consumo_de_kwh * valor_por_kwh;

  total_com_desconto = total_sem_desconto * 0.9;

  printf("\nValor total de cada kwh: R$ %.2f\n", valor_por_kwh);
  printf("Valor a ser pago sem desconto: R$ %.2f\n", total_sem_desconto);
  printf("Valor a ser pago com desconto: R$ %.2f\n", total_com_desconto);

  return 0;
} 